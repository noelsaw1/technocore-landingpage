jQuery(document).ready(function ($) {
    'use strict';

    /* core consts */
    const body = $('body');


});
